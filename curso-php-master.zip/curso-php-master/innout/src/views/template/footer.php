<footer class="footer">
    <span>Desenvolvido com</span>
    <span><i class="icofont-heart text-danger mx-1"></i></span>
    <span>por COD<span class="text-danger">3</span>R</span>
</footer>
<script src="assets/js/app.js"></script>
</body>
</html>