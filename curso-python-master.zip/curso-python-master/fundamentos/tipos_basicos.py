# %%
print(True)
print(False)
print(1.2 + 1)
print('Aqui eu falo na minha lingua!')
print("Tb funciona.")
print('Você é ' + 3 * 'muito ' + 'legal!')
# print(3 + '3') -> ambiguidade
print([1, 2, 3])
print({'nome': 'Pedro', 'idade': 22})
print(None)