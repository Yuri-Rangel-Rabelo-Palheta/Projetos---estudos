# %%
a = 3
a = a + 7
print(a)

# a = 5
a += 5  # a = a + 5
print(a)

a -= 3
print(a)

a *= 2
print(a)

a /= 4
print(a)

a %= 4
print(a)

a **= 8
print(a)

a //= 256
print(a)
