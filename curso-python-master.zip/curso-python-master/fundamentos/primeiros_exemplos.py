# %%
print('primeiro programa')
1 \
 + 2

help(print)

# %%
1 + 2 + 3
4 + 5 + 6

# %%
print(1 + 2 + 3)
print(4 + 5 + 6)
