# %%
a = 3
# a++
# a += 1
# a
# a--
# ++a
# ++a
-a
+a

not 0
not 1
not -2
not False
not not True