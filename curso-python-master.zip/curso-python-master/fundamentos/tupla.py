# %%
tupla = tuple()
tupla = ()
type(tupla)
dir(tupla)
# help(tuple)
type(tupla)
tupla = ('um')
type(tupla)
tupla = ('um',)
type(tupla)
tupla[0]
# tupla[0] = 'novo'
cores = ('verde', 'amarelo', 'azul', 'branco')
cores[0]
cores[-1]
cores[1:]

cores.index('amarelo')
cores.count('Azul')
len(cores)
