# %%
print(2 + 3)
print(4 - 7)
print(2 * 5.3)
print(9.4 / 3)
print(9.4 // 3)
print(2 ** 8)
print(10 % 3)

a = 12
b = a
print(a + b)

# %%
# Minhas variáveis
salario = 3450.45
despesas = 2456.2

# Resposta do desafio
percentual_comprometido = despesas / salario * 100
percentual_comprometido
