# %%
dir(int)
dir(float)

a = 5
b = 2.5
a / b
a + b
a * b

type(a)
type(b)
type(a - b)

b.is_integer()
5.0.is_integer()

dir(int)
int.__add__(2, 3)
2 + 3

(-2).__abs__()
abs(-2)

(-3.6).__abs__()
dir(float)
abs(-3.6)
