# %%
2 + 3
'2' + '3'
# 2 + '3'
# print(2 + '3')

a = 2
b = '3'

print(type(a))
print(type(b))

print(a + int(b))
print(str(a) + b)

type(str(a))

# print(2 + int('3.4'))
