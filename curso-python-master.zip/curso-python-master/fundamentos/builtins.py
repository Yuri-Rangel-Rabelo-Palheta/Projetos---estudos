# type()
type(1)
__builtins__.type('Fala Galera!')
__builtins__.print(10 / 3)

# __builtins__.help(__builtins__.dir)

# a = 7
# import math
# dir()
# dir(__builtins__)


nome = 'João da Silva'
type(nome)
# __builtin__.len(nome)

dir()
