# %%
# Minhas variáveis
salario = 3450.45
despesas = 2456.2

"""
A ideia é calcular o
quando vai sobrar no
final do mes!
"""
print(salario - despesas)

# print('Fim')
print('Fim de verdade')  # comentário aqui tb vale!

'''
A ideia é calcular o
quando vai sobrar no
final do mes!
'''
print('Agora sim o fim de verdade')
