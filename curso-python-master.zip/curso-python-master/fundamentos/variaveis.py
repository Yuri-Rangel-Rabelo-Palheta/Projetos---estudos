# %%
a = 10
b = 5.2

print(a + b)

a = 'Agora sou uma string!'
print(a)
a
b

# print(a + b)