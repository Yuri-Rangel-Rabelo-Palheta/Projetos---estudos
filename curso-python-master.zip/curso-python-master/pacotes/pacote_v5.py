from calc import soma, subtracao

print('Soma', soma(3, 2))
print('Subtração', subtracao(3, 2))
