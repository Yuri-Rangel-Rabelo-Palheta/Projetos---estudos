from random import choice


def novo_nome():
    return choice(['Ana', 'Maria', 'Pedro', 'Rafael'])
