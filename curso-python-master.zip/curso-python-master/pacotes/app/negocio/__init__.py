def nome_existe(nome):
    return False
