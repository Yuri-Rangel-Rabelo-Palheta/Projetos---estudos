from pacote1 import modulo1

print(type(modulo1))
print(modulo1.soma(2, 3))
