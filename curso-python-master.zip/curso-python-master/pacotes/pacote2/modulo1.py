def subtracao(x, y):
    return x - y
