from pacote1 import modulo2

modulo2.main()
