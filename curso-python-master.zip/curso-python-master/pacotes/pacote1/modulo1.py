print(f'importado módulo {__name__} do pacote {__package__}!')


def soma(x, y):
    return x + y
