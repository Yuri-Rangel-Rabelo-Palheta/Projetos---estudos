def main():
    print(f'Rodando o main() no módulo {__name__}')


if __name__ == '__main__':
    main()
