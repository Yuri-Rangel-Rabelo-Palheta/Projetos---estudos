#!/usr/local/bin/python3
from math import pi

raio = input('Informe o raio: ')
print('Área do círculo', pi * float(raio) ** 2)
