# -*- coding: utf-8 -*-
print "你好，世界"
print "Olá Mundo!"