#!/usr/local/bin/python3
from math import pi

if __name__ == '__main__':
    raio = input('Informe o raio: ')
    print('Área do círculo', pi * float(raio) ** 2)
