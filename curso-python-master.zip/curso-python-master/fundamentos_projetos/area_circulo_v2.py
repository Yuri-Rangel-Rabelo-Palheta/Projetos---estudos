# -*- coding: utf-8 -*-
pi = 3.14159
raio = 15.3
print('Área do círculo', pi * raio ** 2)
