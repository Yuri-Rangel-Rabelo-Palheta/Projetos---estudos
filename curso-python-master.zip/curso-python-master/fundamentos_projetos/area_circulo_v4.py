#!/usr/local/bin/python3
# import math
from math import pi

# print(dir())

raio = 15.3
print('Área do círculo', pi * raio ** 2)
