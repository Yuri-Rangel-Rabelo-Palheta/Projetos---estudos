const _ = require('lodash')
setInterval(() => console.log(_.random(50, 60)), 2000)