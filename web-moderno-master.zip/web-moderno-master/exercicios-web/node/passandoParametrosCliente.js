const saudacoes = require('./passandoParametros')('Ana', 'Lucas', 'João')
console.log(saudacoes)