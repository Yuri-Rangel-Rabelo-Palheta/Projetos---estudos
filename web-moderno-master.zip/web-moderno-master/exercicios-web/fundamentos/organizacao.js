console.log(
    "Sentença de código")

{
    {
        console.log("Olá");
        console.log('Mundo!') // Padrão do curso 
    }
}